data "google_iam_role" "roles" {
  count = length(var.roles)
  name  = var.roles[count.index]
}

locals {
  list_with_item_in_front = distinct(concat(distinct(var.remove_permissions), flatten([for perm in data.google_iam_role.roles.*.included_permissions : perm if perm != null])))
  permissions_removed = slice(
    local.list_with_item_in_front,
    length(distinct(var.remove_permissions)),
    length(local.list_with_item_in_front),
  )

  permissions_all = [
    var.permissions,
    local.permissions_removed,
  ]
}

resource "google_project_iam_custom_role" "apigw_custom_roles" {
  provider    = google-beta
  project     = var.project
  role_id     = var.role_id
  title       = var.title
  description = var.description
  permissions = flatten(local.permissions_all)
}
