#############################################
####          APIGEE Org Admin         ######
#############################################

module "apigw_org_admin" {
  source      = "../../modules/custom_apigw_role"
  project     = "${var.project}-${var.envname}"
  role_id     = "ho_apigw_org_admin"
  title       = "ho_apigw_org_admin"
  description = "Apigee Org Admin"

  roles = [
    "roles/apigee.admin",
    "roles/compute.networkAdmin",
    "roles/compute.networkUser",
    "roles/cloudkms.cryptoKeyEncrypterDecrypter",
    "roles/compute.loadBalancerAdmin",
    "roles/logging.viewer",
    "roles/logging.logWriter",
    "roles/cloudkms.admin",
    "roles/certificatemanager.owner",
  ]
  remove_permissions = [
    "resourcemanager.projects.list",
    "networksecurity.firewallEndpoints.delete",
    "networksecurity.firewallEndpoints.create",
    "networksecurity.firewallEndpoints.use",
    "networksecurity.firewallEndpoints.update",
    "networksecurity.firewallEndpoints.get",
    "networksecurity.firewallEndpoints.list",
    "cloudkms.autokeyConfigs.get",
    "cloudkms.autokeyConfigs.update",
    "cloudkms.keyHandles.create",
    "cloudkms.keyHandles.get",
    "cloudkms.keyHandles.list",
    "cloudkms.projects.showEffectiveAutokeyConfig",
  ]
}


#############################################
####          APIGEE Dev Team          ######
#############################################

module "apigw_dev_team" {
  source      = "../../modules/custom_apigw_role"
  project     = "${var.project}-${var.envname}"
  role_id     = "ho_apigw_dev_team"
  title       = "ho_apigw_dev_team"
  description = "Apigee Dev team"

  roles = [
    "roles/apigee.developerAdmin",
    "roles/apigee.apiAdminV2",
    "roles/apigee.environmentAdmin",
    "roles/cloudkms.cryptoKeyEncrypterDecrypter",
    "roles/logging.viewer",
  ]
  remove_permissions = [
    "resourcemanager.projects.list",
  ]
}

#############################################
####          APIGEE Users Team        ######
#############################################

module "apigw_users" {
  source      = "../../modules/custom_apigw_role"
  project     = "${var.project}-${var.envname}"
  role_id     = "ho_apigw_users"
  title       = "ho_apigw_users"
  description = "Apigee Users team"

  roles = [
    "roles/apigee.apiReaderV2",
    "roles/logging.viewer",
  ]
  remove_permissions = [
    "resourcemanager.projects.list",
  ]
}

