####################################################
### IAM policy for Google Cloud KMS crypto key  ####
####################################################


resource "google_project_service_identity" "apigw_sa" {
  provider = google-beta
  service  = "apigee.googleapis.com"
}

resource "google_kms_crypto_key_iam_member" "apigw_sa_db_keyuser" {
  crypto_key_id = google_kms_crypto_key.apigw_runtime_db_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"

  member = "serviceAccount:${google_project_service_identity.apigw_sa.email}"
}

resource "google_kms_crypto_key_iam_member" "apigw_sa_disk_keyuser" {
  crypto_key_id = google_kms_crypto_key.apigw_disk_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"

  member = "serviceAccount:${google_project_service_identity.apigw_sa.email}"
}

####################################################
### IAM policy for Apigw -dev-team              ####
####################################################

resource "google_project_iam_member" "apigw_dev_team" {
  project = "${var.project}-${var.envname}"
  role    = module.apigw_dev_team.custom_role_name
  member  = "serviceAccount:ho-apigw-deployment-sa@ho-cicd.iam.gserviceaccount.com"
}
