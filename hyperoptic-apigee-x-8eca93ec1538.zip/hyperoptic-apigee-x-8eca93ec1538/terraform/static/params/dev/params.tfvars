project = "ho-apigw"
envname = "dev"
region  = "europe-west2"
bucket_name = "ho-apigw-dev-bucket-apigw-backup"
gcp_apis_required = [
    "cloudapis.googleapis.com",            # Google Cloud APIs
    "cloudresourcemanager.googleapis.com", # Cloud Resource Manager API
    "compute.googleapis.com",              # Compute Engine API
    "deploymentmanager.googleapis.com",    # Cloud Deployment Manager V2 API
    "dns.googleapis.com",                  # Google Cloud DNS API
    "iam.googleapis.com",                  # Identity and Access Management (IAM) API
    "iamcredentials.googleapis.com",       # IAM Service Account Credentials API
    "storage-api.googleapis.com",          # Google Cloud Storage JSON API
    "storage-component.googleapis.com",    # Cloud Storage
    "secretmanager.googleapis.com",        # Secret Manager API
    "servicemanagement.googleapis.com",    # Service Management API
    "logging.googleapis.com",              # Stackdriver Logging API
    "monitoring.googleapis.com",           # Stackdriver Monitoring API
    "sourcerepo.googleapis.com",           # Cloud Source Repositories API
    "servicenetworking.googleapis.com",    # Service Networking API
    "cloudkms.googleapis.com",             # KMS API
    "apigee.googleapis.com",               # Google Apigee X API
    "networksecurity.googleapis.com",      # Network Security
    "cloudfunctions.googleapis.com",       # Cloud Functions
    "serviceusage.googleapis.com",         # Service Usage API
    "workflows.googleapis.com",            # Google Cloud Workflows API
    "cloudscheduler.googleapis.com",       # Cloud Scheduler
]
