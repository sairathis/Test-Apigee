###########################################
### Apigee Config Backup Storage Bucket ###
###########################################

resource "google_storage_bucket" "apigw_config_backup" {
  name          = "${var.project}-${var.envname}-apigw-config-backup"
  location      = var.region
  project       = "${var.project}-${var.envname}"
  storage_class = "STANDARD"

  lifecycle_rule {
    condition {
      age = 365
    }
    action {
      type = "Delete"
    }
  }

  versioning {
    enabled = true
  }

  labels = {
    env    = var.envname
    system = "apigw-${var.envname}"
  }
}
