output "apigw_runtime_db_key_id" {
  value = google_kms_crypto_key.apigw_runtime_db_key.id
}


output "apigw_disk_key_id" {
  value = google_kms_crypto_key.apigw_disk_key.id
}

output "apigw_config_backup_id" {
  value = google_storage_bucket.apigw_config_backup.id
}

output "apigw_sa_email" {
  value = google_project_service_identity.apigw_sa.email
}
