###########################################
###  Cloud KMS for Apigee X DB ###########
###########################################

#Keyring

resource "google_kms_key_ring" "apigw_runtime_db_key_ring" {
  name     = "${var.project}-${var.envname}-runtime-db-key-ring"
  location = var.region
  project  = "${var.project}-${var.envname}"
}

# Key

resource "google_kms_crypto_key" "apigw_runtime_db_key" {
  name            = "${var.project}-${var.envname}-runtime-db-key"
  key_ring        = google_kms_key_ring.apigw_runtime_db_key_ring.id
  rotation_period = "100000s"

  lifecycle {
    prevent_destroy = true
  }
  labels = {
    applicationname = "apigee-${var.envname}"
    approver        = "ivicastoicic"
    businessunit    = "sap"
    env             = "${var.envname}"
    system          = "apigw-${var.envname}"
    owner           = "ivicastoicic"
  }

  version_template {
    algorithm = "GOOGLE_SYMMETRIC_ENCRYPTION"
  }
}


##############################################
###  Cloud KMS for Apigee X Runtime Disk #####
##############################################

# Key ring

resource "google_kms_key_ring" "apigw_disk_key_ring" {
  name     = "${var.project}-${var.envname}-disk-key-ring"
  location = var.region
  project  = "${var.project}-${var.envname}"
}

#Key

resource "google_kms_crypto_key" "apigw_disk_key" {
  name            = "${var.project}-${var.envname}-disk-key"
  key_ring        = google_kms_key_ring.apigw_disk_key_ring.id
  rotation_period = "100000s"

  lifecycle {
    prevent_destroy = true
  }

  labels = {
    applicationname = "apigee-${var.envname}"
    approver        = "ivicastoicic"
    businessunit    = "sap"
    env             = "${var.envname}"
    system          = "apigw-${var.envname}"
    owner           = "ivicastoicic"
  }

  version_template {
    algorithm = "GOOGLE_SYMMETRIC_ENCRYPTION"
  }
}
