variable "project" {}
variable "region" {}
variable "envname" {}
variable "bucket_name" {}
variable "gcp_apis_required" {}
