###########################################
###      Apigee VPC Network             ###
###########################################
resource "google_compute_network" "apigw_network" {
  name                    = "apigw-${var.envname}-vpc"
  auto_create_subnetworks = false
}
