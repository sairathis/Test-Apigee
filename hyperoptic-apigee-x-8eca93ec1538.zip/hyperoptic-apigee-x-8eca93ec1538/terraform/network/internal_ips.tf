resource "google_compute_address" "apigw_staticip_snow_mid" {
  name         = "apigw-${var.envname}-staticip-snow-mid"
  subnetwork   = google_compute_subnetwork.apigw_ilb_subnet.id
  address_type = "INTERNAL"
  address      = var.apigw_snow_mid_ip
  region       = var.region
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }

}


resource "google_compute_address" "apigw_staticip_ilb" {
  name         = "apigw-${var.envname}-ilb"
  subnetwork   = google_compute_subnetwork.apigw_ilb_subnet.id
  address_type = "INTERNAL"
  address      = var.apigw_static_ilb_ip
  region       = var.region
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }

}
