resource "google_compute_global_address" "apigw_vpc_psc_range_22" {
  name          = "apigw-${var.envname}-vpc-psc-range-22"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 22
  address       = var.apigw_vpc_psc_ip_adress_range_22
  network       = google_compute_network.apigw_network.id
}


resource "google_compute_global_address" "apigw_vpc_psc_range_28" {
  name          = "apigw-${var.envname}-vpc-psc-range-28"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 28
  address       = var.apigw_vpc_psc_ip_adress_range_28
  network       = google_compute_network.apigw_network.id
}


resource "google_service_networking_connection" "apigw_vpc_psc_connection" {
  network                 = google_compute_network.apigw_network.id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.apigw_vpc_psc_range_22.name, google_compute_global_address.apigw_vpc_psc_range_28.name]
}

resource "google_compute_network_peering_routes_config" "peering_routes" {
  peering = google_service_networking_connection.apigw_vpc_psc_connection.peering
  network = google_compute_network.apigw_network.name

  import_custom_routes = false
  export_custom_routes = true
}
