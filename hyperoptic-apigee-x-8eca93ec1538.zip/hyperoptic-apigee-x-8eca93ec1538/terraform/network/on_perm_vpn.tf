resource "google_compute_ha_vpn_gateway" "ha_gateway1" {
  provider = google-beta
  region   = var.region
  name     = "ho-apigw-${var.envname}-gateway"
  network  = google_compute_network.apigw_network.name
}

resource "google_compute_external_vpn_gateway" "external_gateway1" {
  provider        = google-beta
  name            = "thw"
  redundancy_type = "SINGLE_IP_INTERNALLY_REDUNDANT"
  description     = "An externally managed VPN gateway"
  interface {
    id         = 0
    ip_address = var.on_prem_ip_thw
  }
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }

}

resource "google_compute_external_vpn_gateway" "external_gateway2" {
  provider        = google-beta
  name            = "ma3"
  redundancy_type = "SINGLE_IP_INTERNALLY_REDUNDANT"
  description     = "An externally managed VPN gateway"
  interface {
    id         = 0
    ip_address = var.on_prem_ip_ma3
  }
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }

}

resource "google_compute_router" "router1" {
  name    = "ho-apigw-${var.envname}-dynamic-routing"
  network = google_compute_network.apigw_network.name
  bgp {
    asn = var.gcp_asn
  }
}

resource "google_compute_vpn_tunnel" "tunnel1" {
  provider                        = google-beta
  name                            = "ho-apigw-${var.envname}-thw"
  region                          = var.region
  vpn_gateway                     = google_compute_ha_vpn_gateway.ha_gateway1.self_link
  peer_external_gateway           = google_compute_external_vpn_gateway.external_gateway1.self_link
  peer_external_gateway_interface = 0
  shared_secret                   = var.gcp_shared_secret
  router                          = google_compute_router.router1.self_link
  vpn_gateway_interface           = 0
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }

}

resource "google_compute_vpn_tunnel" "tunnel2" {
  provider                        = google-beta
  name                            = "ho-apigw-${var.envname}-ma3"
  region                          = var.region
  vpn_gateway                     = google_compute_ha_vpn_gateway.ha_gateway1.self_link
  peer_external_gateway           = google_compute_external_vpn_gateway.external_gateway2.self_link
  peer_external_gateway_interface = 0
  shared_secret                   = var.gcp_shared_secret
  router                          = google_compute_router.router1.self_link
  vpn_gateway_interface           = 1
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }

}

resource "google_compute_router_interface" "router1_interface1" {
  name       = "ho-apigw-${var.envname}-bgp-thw"
  router     = google_compute_router.router1.name
  region     = var.region
  ip_range   = var.ip_range_bgppeers_thw
  vpn_tunnel = google_compute_vpn_tunnel.tunnel1.name
}

resource "google_compute_router_peer" "router1_peer1" {
  name            = "ho-apigw-${var.envname}-thw"
  router          = google_compute_router.router1.name
  region          = var.region
  ip_address      = var.bgppeers_ipaddress_thw
  peer_ip_address = var.bgppeers_peeripaddress_thw
  peer_asn        = var.on_prem_asn
  interface       = google_compute_router_interface.router1_interface1.name
  advertise_mode  = "CUSTOM"
  advertised_ip_ranges {
    range = var.advertisedipranges_range_thw
  }
  advertised_ip_ranges {
    range = var.advertisedipranges_range_ma3
  }
}

resource "google_compute_router_interface" "router1_interface2" {
  name       = "ho-apigw-${var.envname}-bgp-ma3"
  router     = google_compute_router.router1.name
  region     = var.region
  ip_range   = var.ip_range_bgppeers_ma3
  vpn_tunnel = google_compute_vpn_tunnel.tunnel2.name
}

resource "google_compute_router_peer" "router1_peer2" {
  name            = "ho-apigw-${var.envname}-ma3"
  router          = google_compute_router.router1.name
  region          = var.region
  ip_address      = var.bgppeers_ipaddress_ma3
  peer_ip_address = var.bgppeers_peeripaddress_ma3
  peer_asn        = var.on_prem_asn
  interface       = google_compute_router_interface.router1_interface2.name
  advertise_mode  = "CUSTOM"
  advertised_ip_ranges {
    range = var.advertisedipranges_range_thw
  }
  advertised_ip_ranges {
    range = var.advertisedipranges_range_ma3
  }
}
