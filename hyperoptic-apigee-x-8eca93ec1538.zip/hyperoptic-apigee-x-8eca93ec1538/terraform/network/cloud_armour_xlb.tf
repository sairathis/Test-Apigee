resource "google_compute_security_policy" "apigw_cloudarmorpolicy_xlb" {
  name = "apigw-${var.envname}-cloudarmorpolicy-xlb"

  rule {
    action   = "deny(403)"
    priority = "101"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_sqli_sensitivity_1
      }
    }
    description = "Deny SQL Injection (Sensitivity level 1)"
  }

  rule {
    action   = "deny(403)"
    priority = "102"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_xss_sensitivity_1
      }
    }
    description = "Deny XSS (Sensitivity level 1)"
  }

  rule {
    action   = "deny(403)"
    priority = "103"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_lfi_sensitivity_1
      }
    }
    description = "Deny LFI (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "104"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_rce_sensitivity_1
      }
    }
    description = "Deny RCE (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "105"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_rfi_sensitivity_1
      }
    }
    description = "Deny RFI (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "106"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_methodenforcement_sensitivity_1
      }
    }
    description = "Deny Method Enforcement (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "107"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_scannerdetection_sensitivity_1
      }
    }
    description = "Deny Scanner Detection (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "108"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_protocolattack_sensitivity_1
      }
    }
    description = "Deny Protocol Attack (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "109"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_php_sensitivity_1
      }
    }
    description = "Deny PHP (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "110"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_sessionfixation_sensitivity_1
      }
    }
    description = "Deny Session Fixation (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "111"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_java_sensitivity_1
      }
    }
    description = "Deny Java (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "112"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_nodejs_sensitivity_1
      }
    }
    description = "Deny Nodejs (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "113"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_cve_canary_sensitivity_1
      }
    }
    description = "Deny CVE Canary (Sensitivity level 1)"
  }
  rule {
    action   = "deny(403)"
    priority = "114"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_jsonsqli_sensitivity_1
      }
    }
    description = "Deny JSON SQLi (Sensitivity level 1)"
  }

  rule {
    action   = "allow"
    priority = "2147483647"
    match {
      versioned_expr = "SRC_IPS_V1"
      config {
        src_ip_ranges = ["*"]
      }
    }
    description = "Default rule - Allow everything "
  }
  rule {
    action   = "deny(403)"
    priority = "201"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_xss_sensitivity_1_941100_filter
      }
    }
    description = "Deny XSS (Sensitivity level 1) - rule 941100 filter"
  }
  rule {
    action   = "deny(403)"
    priority = "202"
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_sqli_sensitivity_1_942190_include
      }
    }
    description = "Deny SQL Injection (Sensitivity level 0) including rule 942190, exclude paths starting with /pci_pal"
  }

  rule {
    action   = "deny(403)"
    priority = 203
    preview  = false
    match {
      expr {
        expression = var.cloudarmor_sqli_sensitivity_0_921150_filter
      }
    }
    description = "Deny SQL Injection (Sensitivity level 0)  including rule 921150, exclude paths starting with /sap-infinity/ & /sap-po/"
  }

}
