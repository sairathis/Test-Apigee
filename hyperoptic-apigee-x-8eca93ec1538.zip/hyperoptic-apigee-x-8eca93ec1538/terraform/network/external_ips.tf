###########################################
###       Apigee StaticIP for XLB       ###
###########################################

resource "google_compute_global_address" "apigw_global_staticip_xlb" {
  name     = "apigw-${var.envname}-global-staticip-xlb"
  provider = google-beta
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }

}

###########################################
###     Apigee StaticIP-1 for Cloud NAT ###
###########################################

resource "google_compute_address" "apigw_staticip_nat_1" {
  name   = "apigw-${var.envname}-staticip-nat-1"
  region = var.region
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }
}

###########################################
###     Apigee StaticIP-2 for Cloud NAT ###
###########################################

resource "google_compute_address" "apigw_staticip_nat_2" {
  name   = "apigw-${var.envname}-staticip-nat-2"
  region = var.region
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }
}
