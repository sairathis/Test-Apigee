variable "project" {}
variable "region" {}
variable "envname" {}
variable "apigw_vpc_psc_ip_adress_range_22" {}
variable "apigw_vpc_psc_ip_adress_range_28" {}
variable "apigw_ilb_proxy_subnet_cidr_range" {}
variable "apigw_ilb_subnet_cidr_range" {}
variable "apigw_psc_neg_subnet_cidr_range" {}
variable "apigw_snow_mid_ip" {}
variable "apigw_static_ilb_ip" {}

variable "cloudarmor_sqli_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('sqli-v33-stable', {'sensitivity': 1, 'opt_out_rule_ids': ['owasp-crs-v030301-id942190-sqli']})"
}

variable "cloudarmor_xss_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('xss-v33-stable', {'sensitivity': 1, 'opt_out_rule_ids': ['owasp-crs-v030301-id941100-xss']})"
}

variable "cloudarmor_lfi_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('lfi-v33-stable', {'sensitivity': 1})"
}

variable "cloudarmor_rce_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('rce-v33-stable', {'sensitivity': 1})"
}

variable "cloudarmor_rfi_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('rfi-v33-stable', {'sensitivity': 1})"
}


variable "cloudarmor_methodenforcement_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('methodenforcement-v33-stable', {'sensitivity': 1})"
}

variable "cloudarmor_scannerdetection_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('scannerdetection-v33-stable', {'sensitivity': 1})"
}

variable "cloudarmor_protocolattack_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('protocolattack-v33-stable', {'sensitivity': 1, 'opt_out_rule_ids': ['owasp-crs-v030301-id921150-protocolattack']})"
}


variable "cloudarmor_php_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('php-v33-stable', {'sensitivity': 1})"
}

variable "cloudarmor_sessionfixation_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('sessionfixation-v33-stable', {'sensitivity': 1})"
}

variable "cloudarmor_java_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('java-v33-stable', {'sensitivity': 1})"
}

variable "cloudarmor_nodejs_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('nodejs-v33-stable', {'sensitivity': 1})"
}

variable "cloudarmor_cve_canary_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('cve-canary', {'sensitivity': 1})"
}

variable "cloudarmor_jsonsqli_sensitivity_1" {
  default = "evaluatePreconfiguredWaf('json-sqli-canary', {'sensitivity': 1})"
}

variable "cloudarmor_xss_sensitivity_1_941100_filter" {
  default = "evaluatePreconfiguredWaf('xss-v33-stable', {'sensitivity': 0, 'opt_in_rule_ids': ['owasp-crs-v030301-id941100-xss']}) && !request.path.startsWith('/sap-infinity/') && !request.path.startsWith('/sap-po/')"
}

variable "cloudarmor_sqli_sensitivity_1_942190_include" {
  default = "evaluatePreconfiguredWaf('sqli-v33-stable', {'sensitivity': 0, 'opt_in_rule_ids': ['owasp-crs-v030301-id942190-sqli']}) && !request.path.startsWith('/pci_pal')"
}

variable "cloudarmor_sqli_sensitivity_0_921150_filter" {
  default = "evaluatePreconfiguredWaf('protocolattack-v33-stable', {'sensitivity': 0, 'opt_in_rule_ids': ['owasp-crs-v030301-id921150-protocolattack']}) && !request.path.startsWith('/sap-infinity/') && !request.path.startsWith('/sap-po/')"
}

## VPN
variable "on_prem_ip_thw" {}
variable "on_prem_ip_ma3" {}
variable "gcp_asn" {}
variable "on_prem_asn" {}
variable "gcp_shared_secret" {}
variable "ip_range_bgppeers_thw" {}
variable "bgppeers_ipaddress_thw" {}
variable "bgppeers_peeripaddress_thw" {}
variable "advertisedipranges_range_thw" {}
variable "ip_range_bgppeers_ma3" {}
variable "bgppeers_ipaddress_ma3" {}
variable "bgppeers_peeripaddress_ma3" {}
variable "advertisedipranges_range_ma3" {}

