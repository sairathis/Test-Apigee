###########################################
###       Network and Subnets           ###
###########################################


output "apigw_network" {
  value = google_compute_network.apigw_network.self_link
}

output "apigw_network_id" {
  value = google_compute_network.apigw_network.id
}


output "apigw_ilb_proxy_subnet_name" {
  value = google_compute_subnetwork.apigw_ilb_proxy_subnet.name
}

output "apigw_ilb_subnet_name" {
  value = google_compute_subnetwork.apigw_ilb_subnet.name
}

output "apigw_ilb_subnet_cidr" {
  value = var.apigw_ilb_subnet_cidr_range
}

output "apigw_psc_neg_subnet_name" {
  value = google_compute_subnetwork.apigw_psc_neg_subnet.name
}

###########################################
###       External IP                   ###
###########################################

output "apigw_global_staticip_xlb_selflink" {
  value = google_compute_global_address.apigw_global_staticip_xlb.self_link
}

output "apigw_global_staticip_xlb_address" {
  value = google_compute_global_address.apigw_global_staticip_xlb.address
}


output "apigw_staticip_snow_mid_address" {
  value = google_compute_address.apigw_staticip_snow_mid.address
}


output "apigw_staticip_ilb_address" {
  value = google_compute_address.apigw_staticip_ilb.address
}

output "apigw_staticip_ilb_id" {
  value = google_compute_address.apigw_staticip_ilb.id
}

output "apigw_public_cloud_dns_zone_name" {
  value = google_dns_managed_zone.apigw_cloud_dns_zone.name
}

output "apigw_cloudarmorpolicy_xlb_name" {
  value = google_compute_security_policy.apigw_cloudarmorpolicy_xlb.name
}


###########################################
###       VPN                           ###
###########################################

output "gcp_external_vpn_address_1" {
  value = google_compute_ha_vpn_gateway.ha_gateway1.vpn_interfaces.0.ip_address
}

output "gcp_external_vpn_address_2" {
  value = google_compute_ha_vpn_gateway.ha_gateway1.vpn_interfaces.1.ip_address
}

