resource "google_dns_managed_zone" "apigw_cloud_dns_zone" {
  name        = var.envname == "prod" ? "apigw-hyperoptic-com" : "apigw-${var.envname}-hyperoptic-com"
  dns_name    = var.envname == "prod" ? "apigw.hyperoptic.com." : "apigw-${var.envname}.hyperoptic.com."
  description = "Apigw  DNS zone"
  cloud_logging_config {
    enable_logging = true
  }
  labels = {
    env    = "${var.envname}"
    system = "apigw-${var.envname}"
  }
}
