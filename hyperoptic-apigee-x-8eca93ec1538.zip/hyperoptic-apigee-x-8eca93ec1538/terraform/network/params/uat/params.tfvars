project = "ho-apigw"
envname = "uat"
region  = "europe-west2"

###VPC AND SUBNETS
apigw_ilb_proxy_subnet_cidr_range = "172.24.43.192/26"
apigw_ilb_subnet_cidr_range = "172.24.42.128/27"
apigw_psc_neg_subnet_cidr_range = "172.24.42.224/27"

### PSC
apigw_vpc_psc_ip_adress_range_22 = "172.24.72.0"
apigw_vpc_psc_ip_adress_range_28 = "172.24.44.96"


### static ip
apigw_snow_mid_ip = "172.24.42.130"
apigw_static_ilb_ip = "172.24.42.132"

### VPN
on_prem_ip_thw = "188.172.144.164"
on_prem_ip_ma3 = "188.172.144.188"

gcp_asn = "64568"
on_prem_asn = "64570"
gcp_shared_secret = "z5tkFJ7MdtjccoHHK9VS+8E9hSeGhMZ2"

ip_range_bgppeers_thw = "169.254.0.142/30"
bgppeers_ipaddress_thw = "169.254.0.142"
bgppeers_peeripaddress_thw = "169.254.0.141"
advertisedipranges_range_thw = "172.24.42.128/27"

ip_range_bgppeers_ma3 = "169.254.0.146/30"
bgppeers_ipaddress_ma3 = "169.254.0.146"
bgppeers_peeripaddress_ma3 = "169.254.0.145"
advertisedipranges_range_ma3 = "172.24.72.0/22"

