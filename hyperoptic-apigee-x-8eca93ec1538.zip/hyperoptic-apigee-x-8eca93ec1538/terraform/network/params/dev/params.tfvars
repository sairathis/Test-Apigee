project = "ho-apigw"
envname = "dev"
region  = "europe-west2"

apigw_ilb_proxy_subnet_cidr_range = "172.24.43.64/26"
apigw_ilb_subnet_cidr_range = "172.24.41.224/27"
apigw_psc_neg_subnet_cidr_range = "172.24.42.160/27"
apigw_vpc_psc_ip_adress_range_22 = "172.24.64.0"
apigw_vpc_psc_ip_adress_range_28 = "172.24.44.64"
### static ip
apigw_snow_mid_ip = "172.24.41.226"
apigw_static_ilb_ip = "172.24.41.229"

## VPN
on_prem_ip_thw = "188.172.144.156"
on_prem_ip_ma3 = "188.172.144.180"

gcp_asn = "64568"
on_prem_asn = "64570"
gcp_shared_secret = "032EMpasUIjUues9Nam8cErgs/X0E3iX"

ip_range_bgppeers_thw = "169.254.0.118/30"
bgppeers_ipaddress_thw = "169.254.0.118"
bgppeers_peeripaddress_thw = "169.254.0.117"
advertisedipranges_range_thw = "172.24.41.224/27"

ip_range_bgppeers_ma3 = "169.254.0.122/30"
bgppeers_ipaddress_ma3 = "169.254.0.122"
bgppeers_peeripaddress_ma3 = "169.254.0.121"
advertisedipranges_range_ma3 = "172.24.64.0/22"
