project = "ho-apigw"
envname = "prod"
region  = "europe-west2"

apigw_ilb_proxy_subnet_cidr_range = "172.24.44.0/26"
apigw_ilb_subnet_cidr_range = "172.24.42.96/27"
apigw_psc_neg_subnet_cidr_range = "172.24.43.0/27"
apigw_vpc_psc_ip_adress_range_22 = "172.24.76.0"
apigw_vpc_psc_ip_adress_range_28 = "172.24.44.112"
### static ip
apigw_snow_mid_ip = "172.24.42.98"
apigw_static_ilb_ip = "172.24.42.100"

## VPN
on_prem_ip_thw = "188.172.144.164"
on_prem_ip_ma3 = "188.172.144.188"

gcp_asn = "64568"
on_prem_asn = "64570"
gcp_shared_secret = "WDFD4O3byPWX+TqsrNfu39Kd+slun/PS"

ip_range_bgppeers_thw = "169.254.0.150/30"
bgppeers_ipaddress_thw = "169.254.0.150"
bgppeers_peeripaddress_thw = "169.254.0.149"
advertisedipranges_range_thw = "172.24.42.96/27"

ip_range_bgppeers_ma3 = "169.254.0.154/30"
bgppeers_ipaddress_ma3 = "169.254.0.154"
bgppeers_peeripaddress_ma3 = "169.254.0.153"
advertisedipranges_range_ma3 = "172.24.76.0/22"

