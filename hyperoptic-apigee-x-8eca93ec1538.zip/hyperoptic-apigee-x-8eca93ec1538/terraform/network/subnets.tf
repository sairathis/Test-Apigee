###########################################
###      Apigee ILB Proxy subnet        ###
###########################################


resource "google_compute_subnetwork" "apigw_ilb_proxy_subnet" {
  name                     = "apigw-${var.envname}-ilb-proxy-subnet"
  region                   = var.region
  network                  = google_compute_network.apigw_network.self_link
  ip_cidr_range            = var.apigw_ilb_proxy_subnet_cidr_range
  private_ip_google_access = false
  role                     = "ACTIVE"
  purpose                  = "REGIONAL_MANAGED_PROXY"
}

###########################################
###      Apigee ILB  subnet             ###
###########################################

resource "google_compute_subnetwork" "apigw_ilb_subnet" {
  name          = "apigw-${var.envname}-ilb-subnet"
  region        = var.region
  network       = google_compute_network.apigw_network.self_link
  ip_cidr_range = var.apigw_ilb_subnet_cidr_range

  log_config {
    aggregation_interval = "INTERVAL_10_MIN"
    flow_sampling        = 0.5
    metadata             = "INCLUDE_ALL_METADATA"
  }

}

###########################################
###      Apigee  PSC NEG subnet         ###
###########################################
resource "google_compute_subnetwork" "apigw_psc_neg_subnet" {
  name          = "apigw-${var.envname}-psc-neg-subnet"
  region        = var.region
  network       = google_compute_network.apigw_network.self_link
  ip_cidr_range = var.apigw_psc_neg_subnet_cidr_range

  log_config {
    aggregation_interval = "INTERVAL_10_MIN"
    flow_sampling        = 0.5
    metadata             = "INCLUDE_ALL_METADATA"
  }

}

