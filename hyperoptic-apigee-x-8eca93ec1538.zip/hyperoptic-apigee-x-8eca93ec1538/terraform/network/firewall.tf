resource "google_compute_firewall" "default" {
  name    = "allow-ssh"
  network = google_compute_network.apigw_network.name

  allow {
    protocol = "tcp"
    ports    = ["22"]
  }
  log_config {
    metadata = "INCLUDE_ALL_METADATA"
  }
  source_ranges = ["10.255.204.0/22", "10.255.86.0/25", "10.255.216.0/22", "10.255.224.0/22", "10.255.0.105/32", "10.255.200.0/22"]
  target_tags   = ["mid-server"]
}
