# Stackdriver monitoring VM groups

module "vm-snowmid-group" {
  source    = "./localmodules/group-common"
  envname   = var.envname
  groupname = "mid"
  iscluster = "true"
}
