# APIGEE - Latency alert
resource "google_monitoring_alert_policy" "apigw_latency_alert" {
  display_name          = "apigw-${var.envname}-latency-alert"
  enabled               = true
  combiner              = "OR"
  notification_channels = [google_monitoring_notification_channel.stackdriver_notificationchannel_pubsub_critical.id, google_monitoring_notification_channel.stackdriver_notificationchannel_email.id, google_monitoring_notification_channel.stackdriver_notificationchannel_email_apigee.id]
  conditions {
    display_name = "APIGEE - latency alert"
    condition_threshold {
      filter     = "resource.type = \"apigee.googleapis.com/Proxy\" AND metric.type = \"apigee.googleapis.com/proxy/latencies\""
      duration   = "600s"
      comparison = "COMPARISON_GT"
      aggregations {
        alignment_period     = "600s"
        per_series_aligner   = "ALIGN_PERCENTILE_95"
        cross_series_reducer = "REDUCE_NONE"
      }
      threshold_value = 600
    }
  }
  documentation {
    content   = "**ALERT**\n\n APIGW ${var.envname} latency alert"
    mime_type = "text/markdown"
  }
  severity = "CRITICAL"
}
