# APIGEE - Traffic spike alert
resource "google_monitoring_alert_policy" "apigw_traffic_spike" {
  display_name          = "apigw-${var.envname}-traffic-spike"
  enabled               = true
  combiner              = "OR"
  notification_channels = [google_monitoring_notification_channel.stackdriver_notificationchannel_pubsub_critical.id, google_monitoring_notification_channel.stackdriver_notificationchannel_email.id, google_monitoring_notification_channel.stackdriver_notificationchannel_email_apigee.id]
  conditions {
    display_name = "APIGEE - Traffic spike alert"
    condition_threshold {
      filter     = "resource.type = \"apigee.googleapis.com/Proxy\" AND metric.type = \"apigee.googleapis.com/proxy/request_count\""
      duration   = "60s"
      comparison = "COMPARISON_GT"
      aggregations {
        alignment_period     = "60s"
        per_series_aligner   = "ALIGN_RATE"
        cross_series_reducer = "REDUCE_NONE"
      }
      threshold_value = 60
    }
  }
  documentation {
    content   = "**ALERT**\n\n APIGW ${var.envname} Traffic spike alert"
    mime_type = "text/markdown"
  }
  severity = "CRITICAL"
}
