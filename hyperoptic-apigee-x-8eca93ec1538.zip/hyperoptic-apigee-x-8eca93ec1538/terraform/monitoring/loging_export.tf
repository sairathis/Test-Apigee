# Export stackdriver log into storage (bucket)
# https://www.terraform.io/docs/providers/google/r/logging_project_sink.html

# Create storage bucket
resource "google_storage_bucket" "apigw_log_export" {
  name          = "apigw-${var.envname}-cloud-logging-export"
  storage_class = "REGIONAL"
  location      = "europe-west2"
  force_destroy = "true"

  versioning {
    enabled = true
  }

  lifecycle_rule {
    action {
      type          = "SetStorageClass"
      storage_class = "NEARLINE"
    }

    condition {
      age = "30"
    }
  }

  lifecycle_rule {
    action {
      type          = "SetStorageClass"
      storage_class = "COLDLINE"
    }

    condition {
      age = "90"
    }
  }

  lifecycle_rule {
    action {
      type = "Delete"
    }

    condition {
      age = "365"
    }
  }

  labels = {
    environment = var.envname
  }

}

# Create Sink
resource "google_logging_project_sink" "apigw_logs_bucket_sink" {
  name                   = "apigw-sink-logs-to-bucket"
  destination            = "storage.googleapis.com/${google_storage_bucket.apigw_log_export.name}"
  unique_writer_identity = true
}

# Permissions
resource "google_project_iam_binding" "apigw_logs_bucket_writer" {
  role    = "roles/storage.objectCreator"
  project = "${var.project}-${var.envname}"
  members = [
    "${google_logging_project_sink.apigw_logs_bucket_sink.writer_identity}",
  ]
}
