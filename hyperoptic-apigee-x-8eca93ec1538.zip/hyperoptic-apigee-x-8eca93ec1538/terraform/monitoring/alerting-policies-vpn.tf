# Stackdriver alerts for VPN

module "vpn_aws" {
  source = "./localmodules/alerting-policies-vpn"
  notification_channels_critical = [
    google_monitoring_notification_channel.stackdriver_notificationchannel_pubsub_critical.name,
  "${google_monitoring_notification_channel.stackdriver_notificationchannel_email_infra.name}"]
  tunnel_name   = var.vpn_tunnel_1_name
  extra_message = var.vpn_tunnel_1_message
}

module "vpn_ma3" {
  source = "./localmodules/alerting-policies-vpn"
  notification_channels_critical = [
    google_monitoring_notification_channel.stackdriver_notificationchannel_pubsub_critical.name,
  "${google_monitoring_notification_channel.stackdriver_notificationchannel_email_infra.name}"]
  tunnel_name   = var.vpn_tunnel_2_name
  extra_message = var.vpn_tunnel_2_message
}

module "vpn_thw" {
  source = "./localmodules/alerting-policies-vpn"
  notification_channels_critical = [
    google_monitoring_notification_channel.stackdriver_notificationchannel_pubsub_critical.name,
  "${google_monitoring_notification_channel.stackdriver_notificationchannel_email_infra.name}"]
  tunnel_name   = var.vpn_tunnel_3_name
  extra_message = var.vpn_tunnel_3_message
}
