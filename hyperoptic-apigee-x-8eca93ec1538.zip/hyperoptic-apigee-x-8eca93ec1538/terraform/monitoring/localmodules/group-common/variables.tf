variable "envname" {}
variable "groupname" {}
variable "iscluster" {}
