resource "google_monitoring_group" "vm" {
  display_name        = "tf-vm-${var.groupname}"
  filter              = "resource.metadata.name=has_substring(\"${var.groupname}\")"
  is_cluster          = "${var.iscluster}"
}
