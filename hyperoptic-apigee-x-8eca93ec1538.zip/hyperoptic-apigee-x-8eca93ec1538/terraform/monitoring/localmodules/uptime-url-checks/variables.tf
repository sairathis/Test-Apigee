variable "envname" {}
variable "path" {}
variable "domainname" {}
variable "project_id" {}
variable "name" {}
variable "notification_channel" {}
