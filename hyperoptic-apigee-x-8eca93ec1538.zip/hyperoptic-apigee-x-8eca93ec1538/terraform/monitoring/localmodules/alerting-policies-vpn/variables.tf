variable "notification_channels_critical" {}
variable "tunnel_name" {}
variable "extra_message" {}
