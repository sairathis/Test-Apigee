# General
variable "envname" {}
variable "name" {}

# Logging Metric
variable "loggingmetricfilter" {}

# Logging Alert
variable "loggingalertfilter" {}
variable "notification_channel" {}
variable "thresholdvalue" {}# General
variable "envname" {}
variable "name" {}

# Logging Metric
variable "loggingmetricfilter" {}

# Logging Alert
variable "loggingalertfilter" {}
variable "notification_channel" {}
variable "thresholdvalue" {}
