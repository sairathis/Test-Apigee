project = "ho-apigw"
envname = "test"
region  = "europe-west2"

vpn_tunnel_1_name = "apigw-test-to-aws-stage-vpc-tunnel1"
vpn_tunnel_2_name = "ho-apigw-test-ma3"
vpn_tunnel_3_name = "ho-apigw-test-thw"
vpn_tunnel_1_message = "AWS VPN Tunnel is down."
vpn_tunnel_2_message = "MA3 VPN Tunnel is down"
vpn_tunnel_3_message = "THW VPN Tunnel is down"

