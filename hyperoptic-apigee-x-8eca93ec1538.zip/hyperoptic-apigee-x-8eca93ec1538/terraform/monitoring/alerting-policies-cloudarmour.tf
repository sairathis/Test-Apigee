# Stackdriver alerts for Cloud Armor

module "cloudarmor_cloudarmorpolicy_vmb_only" {
  source      = "./localmodules/alerting-cloud-armour"
  policy_name = "apigw-${var.envname}-cloudarmorpolicy-xlb"
  notification_channels_critical = [
    google_monitoring_notification_channel.stackdriver_notificationchannel_pubsub_critical.name,
  "${google_monitoring_notification_channel.stackdriver_notificationchannel_email_infra.name}"]
  notification_channels_warning = [
    google_monitoring_notification_channel.stackdriver_notificationchannel_pubsub_warning.name,
  "${google_monitoring_notification_channel.stackdriver_notificationchannel_email_infra.name}"]

  stackdriver_requestsallowedhigh_critical_threshold = "3"
  stackdriver_requestsallowedhigh_warning_threshold  = "7"
  stackdriver_requestsallowedlow_critical_threshold  = var.envname == "prod" ? "0.05" : "0.02"
  stackdriver_requestsallowedlow_warning_threshold   = var.envname == "prod" ? "0.1" : "0.05"
  stackdriver_requestsblockedhigh_critical_threshold = "6"
  stackdriver_requestsblockedhigh_warning_threshold  = "3"
}
