variable "project" {}
variable "region" {}
variable "envname" {}

# VPN
variable "vpn_tunnel_1_name" {}
variable "vpn_tunnel_2_name" {}
variable "vpn_tunnel_3_name" {}

variable "vpn_tunnel_1_message" {}
variable "vpn_tunnel_2_message" {}
variable "vpn_tunnel_3_message" {}
