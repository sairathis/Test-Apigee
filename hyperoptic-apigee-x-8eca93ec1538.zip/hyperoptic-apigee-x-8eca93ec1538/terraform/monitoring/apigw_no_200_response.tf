# APIGEE - Alert for no 200 response code for 5 minutes
resource "google_monitoring_alert_policy" "apigw_no_200_response" {
  display_name          = "apigw-${var.envname}-no-200-response"
  enabled               = true
  combiner              = "OR"
  notification_channels = [google_monitoring_notification_channel.stackdriver_notificationchannel_pubsub_critical.id, google_monitoring_notification_channel.stackdriver_notificationchannel_email.id, google_monitoring_notification_channel.stackdriver_notificationchannel_email_apigee.id]
  conditions {
    display_name = "Alert for no 200 response code for 5 minutes"
    condition_threshold {
      filter     = "resource.type = \"apigee.googleapis.com/Proxy\" AND metric.type = \"apigee.googleapis.com/proxy/response_count\" AND metric.labels.response_code = \"200\""
      duration   = "300s"
      comparison = "COMPARISON_GT"
      aggregations {
        alignment_period     = "300s"
        per_series_aligner   = "ALIGN_RATE"
        cross_series_reducer = "REDUCE_NONE"
      }
    }
  }
  documentation {
    content   = "**ALERT**\n\n APIGW ${var.envname} no 200 response code for 5 minutes"
    mime_type = "text/markdown"
  }
  severity = "CRITICAL"
}
