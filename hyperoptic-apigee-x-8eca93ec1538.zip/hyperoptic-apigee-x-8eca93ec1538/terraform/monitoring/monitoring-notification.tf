
resource "google_project_service_identity" "apigw_sa_monitoring" {
  provider = google-beta
  service  = "monitoring.googleapis.com"
}


## Pub/Sub Perms
# Project ID/Number
data "google_project" "project" {}

# Critical
resource "google_pubsub_topic_iam_member" "pubsub_topic_critical" {
  project = "${var.project}-${var.envname}"
  topic   = google_pubsub_topic.pubsub_topic_critical.name
  role    = "roles/pubsub.publisher"
  member  = "serviceAccount:${google_project_service_identity.apigw_sa_monitoring.email}"
}

# Warning
resource "google_pubsub_topic_iam_member" "pubsub_topic_warning" {
  project = "${var.project}-${var.envname}"
  topic   = google_pubsub_topic.pubsub_topic_warning.name
  role    = "roles/pubsub.publisher"
  member  = "serviceAccount:${google_project_service_identity.apigw_sa_monitoring.email}"
}

## Pub/Sub Topics
# Critical
resource "google_pubsub_topic" "pubsub_topic_critical" {
  project = "${var.project}-${var.envname}"
  name    = "apigw-${var.envname}-monitoring-alert-policies-critical"
}

# Warning
resource "google_pubsub_topic" "pubsub_topic_warning" {
  project = "${var.project}-${var.envname}"
  name    = "apigw-${var.envname}-monitoring-alert-policies-warning"
}

# Pub/Sub Critical
resource "google_monitoring_notification_channel" "stackdriver_notificationchannel_pubsub_critical" {
  project      = "${var.project}-${var.envname}"
  display_name = "Apigee ${var.envname} Monitoring Pub/Sub Channel - Critical"
  type         = "pubsub"
  labels = {
    topic = "${google_pubsub_topic.pubsub_topic_critical.id}"
  }
}

# Pub/Sub Warning
resource "google_monitoring_notification_channel" "stackdriver_notificationchannel_pubsub_warning" {
  project      = "${var.project}-${var.envname}"
  display_name = "Apigee ${var.envname} Monitoring Pub/Sub Channel - Warning"
  type         = "pubsub"
  labels = {
    topic = "${google_pubsub_topic.pubsub_topic_warning.id}"
  }
}


## Notification Channels

# Email
resource "google_monitoring_notification_channel" "stackdriver_notificationchannel_email" {
  project      = "${var.project}-${var.envname}"
  display_name = "Apigee ${var.envname} email Notification"
  type         = "email"
  labels = {
    email_address = "deivendran.jeyagopi@hyperoptic.com"
  }
}

resource "google_monitoring_notification_channel" "stackdriver_notificationchannel_email_apigee" {
  project      = "${var.project}-${var.envname}"
  display_name = "Apigee ${var.envname} email Notification - Mani Saurabh"
  type         = "email"
  labels = {
    email_address = "mani.saurabh@hyperoptic.com"
  }
}


## Notification Channels

# Email
resource "google_monitoring_notification_channel" "stackdriver_notificationchannel_email_infra" {
  project      = "${var.project}-${var.envname}"
  display_name = "Infra team ${var.envname} email Notification"
  type         = "email"
  labels = {
    email_address = "itinfrastructure@hyperoptic.com"
  }
}

