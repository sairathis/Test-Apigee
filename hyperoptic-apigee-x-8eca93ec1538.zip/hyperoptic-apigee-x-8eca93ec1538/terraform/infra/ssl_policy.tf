resource "google_compute_region_ssl_policy" "apigw_region_ssl_policy" {
  name            = "apigw-${var.envname}-region-sslpolicy"
  profile         = "RESTRICTED"
  region          = var.region
  min_tls_version = "TLS_1_2"
}

resource "google_compute_ssl_policy" "apigw_global_ssl_policy" {
  name            = "apigw-${var.envname}-global-sslpolicy"
  profile         = "RESTRICTED"
  min_tls_version = "TLS_1_2"
}
