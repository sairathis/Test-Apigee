###########################################
###  Apigee X Environment Group         ###
###########################################

resource "google_apigee_envgroup" "apigw_ext_env_grp" {
  name      = "apigw-${var.envname}-ext-env-grp"
  hostnames = var.envname == "prod" ? ["apigw.hyperoptic.com"] : ["apigw-${var.envname}.hyperoptic.com"]
  org_id    = google_apigee_organization.apigw_org.id
}

###########################################
###   ApigeeX Environment Group Attach  ###
###########################################

resource "google_apigee_envgroup_attachment" "apigw_ext_env_grp_attach" {
  envgroup_id = google_apigee_envgroup.apigw_ext_env_grp.id
  environment = google_apigee_environment.apigw_environment.name
}


###########################################
###  Apigee X Environment Group         ###
###########################################

resource "google_apigee_envgroup" "apigw_int_env_grp" {
  name      = "apigw-${var.envname}-int-env-grp"
  hostnames = var.envname == "prod" ? ["int.apigw.hyperoptic.com"] : ["int.apigw-${var.envname}.hyperoptic.com"]
  org_id    = google_apigee_organization.apigw_org.id
}

###########################################
###   ApigeeX Environment Group Attach  ###
###########################################

resource "google_apigee_envgroup_attachment" "apigw_int_env_grp_attach" {
  envgroup_id = google_apigee_envgroup.apigw_int_env_grp.id
  environment = google_apigee_environment.apigw_environment.name
}

