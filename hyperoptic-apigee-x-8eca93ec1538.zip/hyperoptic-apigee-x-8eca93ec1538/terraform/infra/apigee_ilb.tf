###########################################
###   ilb for Apigee X                  ###
###########################################


# ilb Backend
resource "google_compute_region_backend_service" "apigw_ilb_backend" {
  name                  = "apigw-${var.envname}-ilb-be"
  project               = "${var.project}-${var.envname}"
  region                = var.region
  load_balancing_scheme = "INTERNAL_MANAGED"
  protocol              = "HTTPS"
  backend {
    group          = google_compute_region_network_endpoint_group.apigw_psc_neg_ilb.id
    balancing_mode = "UTILIZATION"
  }
  log_config {
    enable      = true
    sample_rate = 1.0
  }
}

# ilb Backend URL MAP
resource "google_compute_region_url_map" "apigw_ilb_url_map" {
  name            = "apigw-${var.envname}-ilb-url-map"
  project         = "${var.project}-${var.envname}"
  region          = var.region
  default_service = google_compute_region_backend_service.apigw_ilb_backend.id
}


# ilb target porxy
resource "google_compute_region_target_https_proxy" "apigw_ilb_target_proxy" {
  name                             = "apigw-${var.envname}-ilb-target-proxy"
  project                          = "${var.project}-${var.envname}"
  region                           = var.region
  url_map                          = google_compute_region_url_map.apigw_ilb_url_map.id
  certificate_manager_certificates = ["//certificatemanager.googleapis.com/${google_certificate_manager_certificate.apigw_lib_cert.id}"]
  ssl_policy                       = google_compute_region_ssl_policy.apigw_region_ssl_policy.id
}


# ilb FWD Rule
resource "google_compute_forwarding_rule" "apigw_ilb_forwarding_rule" {
  name                  = "apigw-${var.envname}-ilb-forwarding-rule"
  target                = google_compute_region_target_https_proxy.apigw_ilb_target_proxy.id
  port_range            = 443
  ip_address            = data.terraform_remote_state.network.outputs.apigw_staticip_ilb_id
  load_balancing_scheme = "INTERNAL_MANAGED"
  project               = "${var.project}-${var.envname}"
  region                = var.region
  network               = data.terraform_remote_state.network.outputs.apigw_network_id
  subnetwork            = data.terraform_remote_state.network.outputs.apigw_ilb_subnet_name
  network_tier          = "PREMIUM"
  allow_global_access   = false
  labels = {
    applicationname = "apigee-${var.envname}"
    approver        = "ivicastoicic"
    businessunit    = "sap"
    env             = "${var.envname}"
    system          = "apigw-${var.envname}"
    owner           = "ivicastoicic"
  }

}

