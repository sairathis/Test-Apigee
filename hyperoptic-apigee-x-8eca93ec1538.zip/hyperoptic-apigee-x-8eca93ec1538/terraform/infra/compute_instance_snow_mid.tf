resource "google_compute_instance" "apigw_ce_gcp_mid" {
  name         = "apigw-${var.envname}-gcp-mid"
  machine_type = "n2-standard-4"
  zone         = "${var.region}-a"
  tags = [
    "mid-server",
  ]
  boot_disk {
    auto_delete = true
    device_name = "apigw-${var.envname}-gcp-mid"

    initialize_params {
      image = "projects/ubuntu-os-cloud/global/images/ubuntu-2004-focal-v20240229"
      size  = 100
      type  = "pd-balanced"
    }
  }


  labels = {
    "system"   = "snow",
    "mid-type" = "apigw"
    "env"      = "${var.envname}"
  }

  metadata = {
    ssh-keys               = "${data.template_file.keys.rendered}"
    block-project-ssh-keys = true
  }

  network_interface {
    subnetwork = data.terraform_remote_state.network.outputs.apigw_ilb_subnet_name
    network_ip = data.terraform_remote_state.network.outputs.apigw_staticip_snow_mid_address
  }


  service_account {
    scopes = ["https://www.googleapis.com/auth/devstorage.read_only", "https://www.googleapis.com/auth/logging.write", "https://www.googleapis.com/auth/monitoring.write", "https://www.googleapis.com/auth/service.management.readonly", "https://www.googleapis.com/auth/servicecontrol", "https://www.googleapis.com/auth/trace.append"]
  }

}
