resource "google_apigee_target_server" "apigw_snow_target_server" {
  name        = "ho-apigw-snow-ts"
  description = "SNOW Target Server"
  protocol    = "HTTP"
  host        = var.apigee_snow_ts
  port        = 443
  env_id      = google_apigee_environment.apigw_environment.id
  s_sl_info {
    enabled = true
  }
}
