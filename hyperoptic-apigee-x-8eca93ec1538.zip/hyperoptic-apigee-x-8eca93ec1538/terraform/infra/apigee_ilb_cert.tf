resource "google_certificate_manager_dns_authorization" "apigw_int_crt_auth" {
  name        = "apigw-${var.envname}-int-crt-auth"
  description = "Apigee ILB Domain Auth"
  domain      = var.envname == "prod" ? "int.apigw.hyperoptic.com" : "int.apigw-${var.envname}.hyperoptic.com"
  location    = var.region
  labels = {
    applicationname = "apigee-${var.envname}"
    approver        = "ivicastoicic"
    businessunit    = "sap"
    env             = "${var.envname}"
    system          = "apigw-${var.envname}"
    owner           = "ivicastoicic"
  }

}

resource "google_dns_record_set" "apigw_int_crt_auth_cname" {
  name         = google_certificate_manager_dns_authorization.apigw_int_crt_auth.dns_resource_record[0].name
  project      = "${var.project}-${var.envname}"
  managed_zone = data.terraform_remote_state.network.outputs.apigw_public_cloud_dns_zone_name
  type         = google_certificate_manager_dns_authorization.apigw_int_crt_auth.dns_resource_record[0].type
  ttl          = 300
  rrdatas      = [google_certificate_manager_dns_authorization.apigw_int_crt_auth.dns_resource_record[0].data]
}


resource "google_certificate_manager_certificate" "apigw_lib_cert" {
  name        = "apigw-${var.envname}-ilb-crt"
  description = "GCP managed ILB cert - APIGW"
  scope       = "DEFAULT"
  location    = var.region
  managed {
    domains = [
      google_certificate_manager_dns_authorization.apigw_int_crt_auth.domain,
    ]
    dns_authorizations = [
      google_certificate_manager_dns_authorization.apigw_int_crt_auth.id,
    ]
  }
  labels = {
    applicationname = "apigee-${var.envname}"
    approver        = "ivicastoicic"
    businessunit    = "sap"
    env             = "${var.envname}"
    system          = "apigw-${var.envname}"
    owner           = "ivicastoicic"
  }
}
