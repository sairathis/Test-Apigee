###########################################
###   XLB for Apigee X                  ###
###########################################


# XLB Backend
resource "google_compute_backend_service" "apigw_xlb_backend" {
  name                  = "apigw-${var.envname}-xlb-be"
  project               = "${var.project}-${var.envname}"
  load_balancing_scheme = "EXTERNAL_MANAGED"
  protocol              = "HTTPS"

  backend {
    group = google_compute_region_network_endpoint_group.apigw_psc_neg_xlb.id
  }
  security_policy = data.terraform_remote_state.network.outputs.apigw_cloudarmorpolicy_xlb_name
  log_config {
    enable      = true
    sample_rate = 1.0
  }
}

# XLB Backend URL MAP
resource "google_compute_url_map" "apigw_xlb_url_map" {
  name            = "apigw-${var.envname}-xlb-url-map"
  project         = "${var.project}-${var.envname}"
  default_service = google_compute_backend_service.apigw_xlb_backend.id
}

# GCP managed cert for xlb domain
resource "google_compute_managed_ssl_certificate" "apigw_ext_cert" {
  name    = "apigw-${var.envname}-ext-cert"
  project = "${var.project}-${var.envname}"
  managed {
    domains = [var.envname == "prod" ? "apigw.hyperoptic.com" : "apigw-${var.envname}.hyperoptic.com"]
  }
}

# XLB target porxy
resource "google_compute_target_https_proxy" "apigw_target_proxy" {
  name             = "apigw-${var.envname}-xlb-target-proxy"
  project          = "${var.project}-${var.envname}"
  url_map          = google_compute_url_map.apigw_xlb_url_map.id
  ssl_certificates = [google_compute_managed_ssl_certificate.apigw_ext_cert.id]
  ssl_policy       = google_compute_ssl_policy.apigw_global_ssl_policy.id
}


# XLB FWD Rule
resource "google_compute_global_forwarding_rule" "apigw_xlb_forwarding_rule" {
  name                  = "apigw-${var.envname}-xlb-forwarding-rule"
  target                = google_compute_target_https_proxy.apigw_target_proxy.id
  port_range            = 443
  load_balancing_scheme = "EXTERNAL_MANAGED"
  ip_address            = data.terraform_remote_state.network.outputs.apigw_global_staticip_xlb_selflink
  project               = "${var.project}-${var.envname}"
  labels = {
    applicationname = "apigee-${var.envname}"
    approver        = "ivicastoicic"
    businessunit    = "sap"
    env             = "${var.envname}"
    system          = "apigw-${var.envname}"
    owner           = "ivicastoicic"
  }
}
