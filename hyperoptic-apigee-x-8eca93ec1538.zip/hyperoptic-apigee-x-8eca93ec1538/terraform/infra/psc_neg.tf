###########################################
###   PSC NEG FOR XLB                   ###
###########################################


resource "google_compute_region_network_endpoint_group" "apigw_psc_neg_xlb" {
  name    = "apigw-${var.envname}-psc-neg-xlb"
  region  = var.region
  project = "${var.project}-${var.envname}"

  network_endpoint_type = "PRIVATE_SERVICE_CONNECT"
  psc_target_service    = google_apigee_instance.apigw_runtime_instance.service_attachment

  network    = data.terraform_remote_state.network.outputs.apigw_network_id
  subnetwork = data.terraform_remote_state.network.outputs.apigw_ilb_subnet_name
}


###########################################
###   PSC NEG FOR ILB                   ###
###########################################


resource "google_compute_region_network_endpoint_group" "apigw_psc_neg_ilb" {
  name    = "apigw-${var.envname}-psc-neg-ilb"
  region  = var.region
  project = "${var.project}-${var.envname}"

  network_endpoint_type = "PRIVATE_SERVICE_CONNECT"
  psc_target_service    = google_apigee_instance.apigw_runtime_instance.service_attachment

  network    = data.terraform_remote_state.network.outputs.apigw_network_id
  subnetwork = data.terraform_remote_state.network.outputs.apigw_ilb_subnet_name
}
