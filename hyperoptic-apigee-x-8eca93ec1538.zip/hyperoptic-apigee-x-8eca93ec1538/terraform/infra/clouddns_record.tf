# Apigee X XLB DNS 
resource "google_dns_record_set" "apigw_xlb_dns_record" {
  # name        = "apigw-${var.envname}.hyperoptic.com."
  name         = var.envname == "prod" ? "apigw.hyperoptic.com." : "apigw-${var.envname}.hyperoptic.com."
  project      = "${var.project}-${var.envname}"
  managed_zone = data.terraform_remote_state.network.outputs.apigw_public_cloud_dns_zone_name
  type         = "A"
  ttl          = 60
  rrdatas      = [data.terraform_remote_state.network.outputs.apigw_global_staticip_xlb_address]
}

# Apigee X XLB DNS
resource "google_dns_record_set" "apigw_ilb_dns_record" {
  #name         = "int.apigw-${var.envname}.hyperoptic.com."
  name         = var.envname == "prod" ? "int.apigw.hyperoptic.com." : "int.apigw-${var.envname}.hyperoptic.com."
  project      = "${var.project}-${var.envname}"
  managed_zone = data.terraform_remote_state.network.outputs.apigw_public_cloud_dns_zone_name
  type         = "A"
  ttl          = 300
  rrdatas      = [data.terraform_remote_state.network.outputs.apigw_staticip_ilb_address]
}
