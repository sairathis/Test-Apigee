project = "ho-apigw"
envname = "prod"
region  = "europe-west2"

### Apigee X Values

apigw_billing_type = "SUBSCRIPTION"
apigw_runtime_type = "CLOUD"
apigw_runtime_instance_iprange = "172.24.44.112/28"

apigee_snow_ts = "hyperopticprod.service-now.com"
