project = "ho-apigw"
envname = "dev"
region  = "europe-west2"

### Apigee X Values

apigw_billing_type = "SUBSCRIPTION"
apigw_runtime_type = "CLOUD"
apigw_runtime_instance_iprange = "172.24.44.64/28"

apigee_snow_ts = "hyperopticdev.service-now.com"
