project = "ho-apigw"
envname = "test"
region  = "europe-west2"

### Apigee X Values

apigw_billing_type = "SUBSCRIPTION"
apigw_runtime_type = "CLOUD"
apigw_runtime_instance_iprange = "172.24.44.80/28"

apigee_snow_ts = "hyperoptictest.service-now.com"
