variable "project" {}
variable "region" {}
variable "envname" {}
variable "apigw_billing_type" {}
variable "apigw_runtime_type" {}
variable "apigee_snow_ts" {}
variable "apigw_runtime_instance_iprange" {}
