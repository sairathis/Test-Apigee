###########################################
###   Apigee Runtime Instance           ###
###########################################

resource "google_apigee_instance" "apigw_runtime_instance" {
  name                     = "apigw-${var.envname}-instance"
  description              = "ApigeeX Runtime Instance"
  display_name             = "apigw-${var.envname}-instance"
  location                 = var.region
  ip_range                 = var.apigw_runtime_instance_iprange
  org_id                   = google_apigee_organization.apigw_org.id
  disk_encryption_key_name = data.terraform_remote_state.static.outputs.apigw_disk_key_id
}



resource "google_apigee_instance_attachment" "apigw_runtime_instance_attach" {
  instance_id = google_apigee_instance.apigw_runtime_instance.id
  environment = google_apigee_environment.apigw_environment.name
}

