###########################################
###   ApigeeX Environment               ###
###########################################
resource "google_apigee_environment" "apigw_environment" {
  # name         = "apigw-${var.envname}-environment"
  name = var.envname == "prod" ? "apigw-environment" : "apigw-${var.envname}-environment"
  # display_name = "apigw-${var.envname}-environment"
  display_name = var.envname == "prod" ? "apigw-environment" : "apigw-${var.envname}-environment"
  description  = "This environment is dedicated to hosting ${var.envname} APIs and services."
  org_id       = google_apigee_organization.apigw_org.id
}

