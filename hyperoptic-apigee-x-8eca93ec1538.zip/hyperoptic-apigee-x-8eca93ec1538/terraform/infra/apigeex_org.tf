###########################################
###   Apigee Orgnization Creation       ###
###########################################

resource "google_apigee_organization" "apigw_org" {
  analytics_region                     = var.region
  project_id                           = "${var.project}-${var.envname}"
  display_name                         = "${var.project}-${var.envname}"
  authorized_network                   = data.terraform_remote_state.network.outputs.apigw_network_id
  billing_type                         = var.apigw_billing_type
  runtime_type                         = var.apigw_runtime_type
  runtime_database_encryption_key_name = data.terraform_remote_state.static.outputs.apigw_runtime_db_key_id
}
