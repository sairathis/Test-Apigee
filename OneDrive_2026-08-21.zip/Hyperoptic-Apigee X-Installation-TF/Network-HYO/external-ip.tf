
# Configure External IP for HTTPS External Load Balancer
resource "google_compute_global_address" "lb_ip" {
  name          = "apigw-dev-lb-eip"
  purpose       = "GLOBAL"
  address_type  = "EXTERNAL"
}

# Configure two static External IPs for Cloud NAT
resource "google_compute_address" "nat_ip_1" {
  name         = "apigw-dev-nat-ip-1"
  address_type = "EXTERNAL"
}

resource "google_compute_address" "nat_ip_2" {
  name         = "apigw-dev-nat-ip-2"
  address_type = "EXTERNAL"
}
