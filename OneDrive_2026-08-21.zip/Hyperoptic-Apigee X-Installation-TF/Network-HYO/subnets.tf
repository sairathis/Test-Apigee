# Subnets
resource "google_compute_subnetwork" "lb_proxy_subnet" {
  name          = "apigw-dev-lb-proxy-subnet"
  network       = google_compute_network.apigee_vpc.self_link
  region        = var.region
  ip_cidr_range = "10.255.32.0/27"
}

resource "google_compute_subnetwork" "ilb_subnet" {
  name          = "apigw-dev-ilb-subnet"
  network       = google_compute_network.apigee_vpc.self_link
  region        = var.region
  ip_cidr_range = "172.24.41.224/27"
}

resource "google_compute_subnetwork" "psc_neg_subnet" {
  name          = "apigw-dev-psc-neg-subnet"
  network       = google_compute_network.apigee_vpc.self_link
  region        = var.region
  ip_cidr_range = "10.255.32.32/27"
}

