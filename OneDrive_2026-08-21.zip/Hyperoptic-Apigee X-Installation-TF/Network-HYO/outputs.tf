output "apigee_network_link" {
  value = google_compute_network.apigee_network.self_link
}

# AdminNAT
output "apigee_subnet_link" {
  value = google_compute_subnetwork.apigee_subnet.self_link
}

output "apigee_subnet_name" {
  value = google_compute_subnetwork.apigee_subnet.name
}

output "hyo_prodapt_subnet_cidr" {
  value = google_compute_subnetwork.apigee_subnet.ip_cidr_range
}