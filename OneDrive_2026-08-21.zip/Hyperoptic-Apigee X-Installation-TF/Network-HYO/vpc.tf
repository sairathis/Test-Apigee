## Network
# HYO Network
resource "google_compute_network" "apigee_network" {
  name                    = "apigw-network-${var.envname}"
  auto_create_subnetworks = false
}

