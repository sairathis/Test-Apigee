resource "google_compute_region_backend_service" "psc_neg_backend_service" {
  name        = "apigw-dev-psc-neg"
  region      = var.region
  protocol    = "HTTP"
  timeout_sec = 30

  backend {
    group = google_compute_backend_service.psc_backend_service.id
  }
}

resource "google_compute_forwarding_rule" "ilb" {
  name             = var.ilb_name
  region           = var.region
  backend_service  = google_compute_region_backend_service.psc_neg_backend_service.self_link

  ip_address {
    subnetwork_project = var.project_id
    subnetwork         = var.ilb_proxy_subnet
  }

  port_range = 80
}

resource "google_compute_global_forwarding_rule" "frontend" {
  name        = var.frontend_name
  target      = google_compute_forwarding_rule.ilb.self_link
  port_range  = 80
  ip_address {
    subnetwork_project = var.project_id
    subnetwork         = var.frontend_subnet
  }
}
