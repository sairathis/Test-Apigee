# Create a Private Service Connect NEG
resource "google_compute_backend_service" "psc_backend_service" {
  name        = var.psc_backend_service_name
  project     = var.project_id
  description = "Backend service for PSC Managed Service"
  protocol    = "HTTP"
  
  # Other configurations for the managed backend service
  
  security_policy = "your-security-policy"  # Replace with your actual security policy
}

resource "google_compute_internal_backend_service" "psc_neg_internal_backend_service" {
  name        = "apigw-dev-psc-neg"
  region      = var.region
  protocol    = "HTTP"
  timeout_sec = 30

  backend {
    group = google_compute_backend_service.psc_backend_service.id
  }
}
