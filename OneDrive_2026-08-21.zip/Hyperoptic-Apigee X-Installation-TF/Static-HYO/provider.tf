provider "google" {
  credentials = file("../${var.project}.json")
  project     = var.project
  region      = var.region 
}

provider "google-beta" {
  credentials = file("../${var.project}.json")
  project     = var.project
  region      = var.region 
}