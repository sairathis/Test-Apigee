resource "google_project_iam_custom_role" "apigee_organisation_admin" {
  role_id     = "apigee_organisation_admin"
  title       = "Apigee Organisation Admin"
  description = "Apigee organization admin role"
  permissions = [
    "roles/apigee.admin",
    "roles/compute.networkAdmin",
    "roles/cloudkms.cryptoKeyEncrypterDecrypter",
    "roles/compute.loadBalancerAdmin",
    "roles/compute.networkUser",
    "roles/logging.viewer",
    "roles/logging.logWriter",
    "roles/cloudkms.admin",
    "roles/certificatemanager.owner",
    "roles/viewer",
    "roles/apigee.apiAdminV2",
    "roles/apigee.developerAdmin",
    "roles/apigee.environmentAdmin",
  ]
}

resource "google_project_iam_custom_role" "apigee_dev_team" {
  role_id     = "apigee_dev_team"
  title       = "Apigee Dev Team"
  description = "Apigee development team role"
  permissions = [
    "roles/apigee.developerAdmin",
    "roles/apigee.apiAdminV2",
    "roles/apigee.environmentAdmin",
    "roles/logging.viewer",
    "roles/viewer",
    "roles/cloudkms.cryptoKeyEncrypterDecrypter",
  ]
}

resource "google_project_iam_custom_role" "apigee_users" {
  role_id     = "apigee_users"
  title       = "Apigee Users"
  description = "Apigee users role"
  permissions = [
    "roles/logging.viewer",
    "roles/viewer",
    "roles/apigee.apiReaderV2",
  ]
}

# Assign IAM roles to service accounts or users
resource "google_project_iam_binding" "assign_apigee_organisation_admin" {
  project = var.project
  role    = google_project_iam_custom_role.apigee_organisation_admin.name

  members = [
    "serviceAccount:${var.project}@appspot.gserviceaccount.com",
  ]
}

resource "google_project_iam_binding" "assign_apigee_dev_team" {
  project = var.project
  role    = google_project_iam_custom_role.apigee_dev_team.name

  members = [
    "serviceAccount:${var.project}@appspot.gserviceaccount.com",  
  ]
}

resource "google_project_iam_binding" "assign_apigee_users" {
  project = var.project
  role    = google_project_iam_custom_role.apigee_users.name

  members = [
    "serviceAccount:${var.project}@appspot.gserviceaccount.com",
  ]
}
