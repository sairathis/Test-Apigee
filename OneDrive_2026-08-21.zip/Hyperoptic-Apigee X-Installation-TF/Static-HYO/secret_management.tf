\
# Create a secret for storing API key
resource "google_secret_manager_secret" "api_key_secret" {
  provider = google-beta
  project  = var.project
  secret_id = "apigw-api-key-secret"  # Name of the secret
}

# Add the API key as a version of the secret
resource "google_secret_manager_secret_version" "api_key_secret_version" {
  provider    = google-beta
  project     = var.project
  secret      = google_secret_manager_secret.api_key_secret.name
  secret_data = "YOUR-API-KEY-HERE"  # Replace with your actual API key
}
