# Define IAM roles and permissions for Apigee X build
resource "google_project_iam_member" "apigee_admin" {
  project = var.project
  role    = "roles/apigee.admin"
  member  = "serviceAccount:ho-apigw-tf-sa@ho-cicd.iam.gserviceaccount.com" 
}

resource "google_project_iam_member" "serviceusage_admin" {
  project = var.project
  role    = "roles/serviceusage.admin"
  member  = "serviceAccount:ho-apigw-tf-sa@ho-cicd.iam.gserviceaccount.com" 
}
resource "google_project_iam_member" "cloudkms_admin" {
  project = var.project
  role    = "roles/cloudkms.admin"
  member  = "serviceAccount:ho-apigw-tf-sa@ho-cicd.iam.gserviceaccount.com" 
}
resource "google_project_iam_member" "compute_network_admin" {
  project = var.project
  role    = "roles/compute.networkAdmin"
  member  = "serviceAccount:ho-apigw-tf-sa@ho-cicd.iam.gserviceaccount.com" 
}

