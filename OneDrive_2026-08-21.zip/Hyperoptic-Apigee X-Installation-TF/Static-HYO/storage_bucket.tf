resource "google_storage_bucket" "ho-test-bucket" {
  name          = var.bucket_name
  location      = "europe-west-2" 
  force_destroy = true 

  uniform_bucket_level_access = true 

  # Bucket labels (optional)
  labels = {
    environment = "apigw-dev"
  }
}