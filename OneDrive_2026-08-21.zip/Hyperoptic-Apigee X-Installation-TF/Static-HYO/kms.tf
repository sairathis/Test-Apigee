resource "google_kms_key_ring" "example_key_ring" {
  name     = "apigw-dev-key-ring"
  location = var.region
}

resource "google_kms_crypto_key" "example_crypto_key" {
  name            = "apigw-dev-crypto-key"
  key_ring        = google_kms_key_ring.example_key_ring.self_link
  purpose         = "ENCRYPT_DECRYPT"
  rotation_period = "100000s"
}

