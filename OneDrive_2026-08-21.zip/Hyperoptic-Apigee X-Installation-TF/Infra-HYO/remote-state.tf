data "terraform_remote_state" "static" {
  backend = "gcs"
  # NOTE: 'equals' char below is critical! I think this is a change in Terraform 0.12
  config = {
    bucket = "hyperoptic-dev-ho-tf-state-apigge-eu-w2"
    prefix = "tfstate-static"
  }
}

data "terraform_remote_state" "network" {
  backend = "gcs"
  # NOTE: 'equals' char below is critical! I think this is a change in Terraform 0.12
  config = {
    bucket = "hyperoptic-dev-ho-tf-state-apigge-eu-w2"
    prefix = "tfstate-network"
  }
}