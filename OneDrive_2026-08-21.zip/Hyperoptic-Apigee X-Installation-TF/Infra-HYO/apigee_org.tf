# Apigee X Org
resource "google_apigee_organization" "hyo_apigee_org" {
  analytics_region    = var.region
  project_id          = var.project
  display_name        = var.display_name
  authorized_network  = data.terraform_remote_state.network.outputs.apigee_network_link
  billing_type        = var.billing_type
  runtime_type        = var.runtime_type
  retention           = var.retention
  disable_vpc_peering = var.disable_vpc_peering
 
}
