resource "google_compute_global_address" "apigee_range" {
  name          = "global-psconnect-ip"
  address_type  = "INTERNAL"
  prefix_length = 16
  purpose       = "PRIVATE_SERVICE_CONNECT"
  network       = data.terraform_remote_state.network.outputs.hyo_prodapt_vpc_link
}

resource "google_service_networking_connection" "apigee_vpc_connection" {
  network                 = data.terraform_remote_state.network.outputs.hyo_prodapt_vpc_link
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.apigee_range.name]
}


