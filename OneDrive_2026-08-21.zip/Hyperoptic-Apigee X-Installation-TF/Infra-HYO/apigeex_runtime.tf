# apigeex_runtime.tf
resource "apigee_runtime_instance" "apigw-dev-instance" {
  name                  = var.name
  location              = var.region
  org_id                = google_apigee_organization.hyo_apigee_org.id
  peering_cidr_range    = "slash_22"
  disk_encryption_key_name = google_kms_crypto_key.apigee_key.self_link
  #consumer_accept_list  = ["<list consumer project>"]
  consumer_accept_list  = ["ho-apigw-dev"]
}
