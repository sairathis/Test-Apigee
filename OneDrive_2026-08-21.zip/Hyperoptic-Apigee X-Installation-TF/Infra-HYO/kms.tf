resource "google_kms_key_ring" "apigee_keyring" {
  name     = "hyperoptic-dev-apigee-keyring"
  location = "europe-west-2"
}

resource "google_kms_crypto_key" "apigee_key" {
  name     = "apigee-key"
  key_ring = google_kms_key_ring.apigee_keyring.id

  lifecycle {
    prevent_destroy = false
  }
}

resource "google_project_service_identity" "apigee_sa" {
  provider = google-beta
  project  = var.project
  service  = "apigee.googleapis.com"
}

resource "google_kms_crypto_key_iam_member" "apigee_sa_keyuser" {
  crypto_key_id = google_kms_crypto_key.apigee_key.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"

  member = "serviceAccount:${google_project_service_identity.apigee_sa.email}"
}
