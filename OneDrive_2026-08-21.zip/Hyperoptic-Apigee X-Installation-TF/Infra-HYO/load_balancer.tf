# ILB for primary region
resource "google_compute_internal_address" "apigw-dev-ilb" {
  name       = "apigw-dev-ilb"
  subnetwork = google_compute_subnetwork.apigw-dev-ilb-proxy-subnet.id
}

resource "google_compute_region_backend_service" "apigw-dev-psc-neg" {
  name   = "apigw-dev-psc-neg"
  region = var.region

  backend {
    group = google_compute_network_endpoint_group.apigw-dev-psc-neg.id
  }
}

resource "google_compute_network_endpoint_group" "apigw-dev-psc-neg" {
  name                  = "apigw-dev-psc-neg"
  network               = data.terraform_remote_state.network.outputs.apigee_network_link
  default_port          = 443
  subnetwork            = google_compute_subnetwork.apigw-dev-ilb-proxy-subnet.id
  network_endpoint_type = "SERVERLESS"
}

resource "google_compute_global_forwarding_rule" "apigw-dev-ilb-forwarding-rule" {
  name                  = "apigw-dev-ilb-fe"
  target                = google_compute_region_backend_service.apigw-dev-psc-neg.id
  port_range            = "443"
  ip_protocol           = "TCP"
  load_balancing_scheme = "INTERNAL"
}

# ILB for secondary region
resource "google_compute_internal_address" "apigw-dev-xlb" {
  name       = "apigw-dev-xlb"
  subnetwork = google_compute_subnetwork.apigw-dev-xlb-proxy-subnet.id
}

resource "google_compute_region_backend_service" "apigw-dev-psc-neg-xlb" {
  name   = "apigw-dev-psc-neg-xlb"
  region = var.region

  backend {
    group = google_compute_network_endpoint_group.apigw-dev-psc-neg-xlb.id
  }
}

resource "google_compute_network_endpoint_group" "apigw-dev-psc-neg-xlb" {
  name                  = "apigw-dev-psc-neg-xlb"
  network               = data.terraform_remote_state.network.outputs.apigee_network_link
  default_port          = 443
  subnetwork            = google_compute_subnetwork.apigw-dev-xlb-proxy-subnet.id
  network_endpoint_type = "SERVERLESS"
}

resource "google_compute_global_forwarding_rule" "apigw-dev-xlb-forwarding-rule" {
  name                  = "apigw-dev-xlb-fe"
  target                = google_compute_region_backend_service.apigw-dev-psc-neg-xlb.id
  port_range            = "443"
  ip_protocol           = "TCP"
  load_balancing_scheme = "INTERNAL"
}
