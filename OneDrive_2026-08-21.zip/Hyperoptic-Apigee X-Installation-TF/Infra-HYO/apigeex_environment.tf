# apigeex_environment.tf

# Create Env Group
resource "apigee_environment_group" "apigw-dev-env-grp" {
  name     = "apigw-dev-env-grp"
  org_id   = google_apigee_organization.hyo_apigee_org.id
  hostname = "apigw-dev.hyperoptic.com"
}

# Create Environment
resource "apigee_environment" "apigw-dev-environment" {
  name            = "apigw-dev-environment"
  displayname     = ""
  description     = ""
  org_id          = google_apigee_organization.hyo_apigee_org.id
  envgroup_id     = apigee_environment_group.apigw-dev-env-grp.id
  node_config {
    min_node     = 2
    max_node     = 100
  }
}
