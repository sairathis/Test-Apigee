output "hyo_prodapt_vpc_link" {
  value = google_compute_network.hyo_prodapt.self_link
}

# AdminNAT
output "hyo_prodapt_subnet_link" {
  value = google_compute_subnetwork.hyo_prodapt_subnet.self_link
}

output "hyo_prodapt_subnet_name" {
  value = google_compute_subnetwork.hyo_prodapt_subnet.name
}

output "hyo_prodapt_subnet_cidr" {
  value = google_compute_subnetwork.hyo_prodapt_subnet.ip_cidr_range
}