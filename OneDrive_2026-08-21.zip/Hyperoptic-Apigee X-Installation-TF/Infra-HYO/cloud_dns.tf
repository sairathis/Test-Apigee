# cloud_dns.tf


# Create Cloud DNS zone for dev environment
resource "google_dns_managed_zone" "dev_zone" {
  name        = "apigw-dev-hyperoptic-com"
  dns_name    = "apigw-dev.hyperoptic.com."
  description = "Managed Zone for the dev environment"
}

# Create DNS record sets for external and internal resolution
resource "google_dns_record_set" "dev_external" {
  name         = "apigw-dev.hyperoptic.com."
  managed_zone = google_dns_managed_zone.dev_zone.name
  type         = "A"
  ttl          = 300
  rrdatas      = [var.dev_ilb_ip]
}

resource "google_dns_record_set" "dev_internal" {
  name         = "apigw-dev-int.hyperoptic.com."
  managed_zone = google_dns_managed_zone.dev_zone.name
  type         = "CNAME"
  ttl          = 300
  rrdatas      = ["apigw-dev.hyperoptic.com."]
}
